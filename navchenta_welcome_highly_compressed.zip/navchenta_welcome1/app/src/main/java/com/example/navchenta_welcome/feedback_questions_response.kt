package com.example.navchenta_welcome

class feedback_questions_response(
    val questions : String,
    val mode : String,
    val option1 : String,
    val option2 : String,
    val option3 : String,
    val option4 : String,
    val long_answer : String,

)