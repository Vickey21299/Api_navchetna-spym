package com.example.navchenta_welcome

class language_selected(
    val language : String
)