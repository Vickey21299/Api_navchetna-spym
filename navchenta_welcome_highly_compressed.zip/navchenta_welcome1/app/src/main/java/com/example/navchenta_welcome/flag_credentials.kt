package com.example.navchenta_welcome

class flag_credentials(
    val email : String
)