package com.example.navchenta_welcome

class credentials (
    val email : String,
    val password : String
)