package com.example.navchenta_welcome

class session_create_data (
    val emailid_T1 : String,
    val emailid_T2 : String,
    val state : String,
    val district : String,
    val address : String,
    val capacity : Int,
    val datetime : String,
    val status : String
)