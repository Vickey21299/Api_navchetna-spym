package com.example.navchenta_welcome

class feedback_get(
    val email : String,
    val rating : String,
    val answer : String
)
